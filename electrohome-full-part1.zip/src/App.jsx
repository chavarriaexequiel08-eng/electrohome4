import React, {useEffect,useMemo,useState} from 'react';
import { Search, ShoppingCart, Plus, Minus } from 'lucide-react';
const CURRENCY="ARS"; 
const fmt=(n)=>new Intl.NumberFormat("es-AR",{style:"currency",currency:CURRENCY,maximumFractionDigits:0}).format(Number(n||0));
export default function App(){
  const [products,setProducts]=useState(null);
  const [cat,setCat]=useState("TODOS");
  const [q,setQ]=useState("");
  const [cart,setCart]=useState([]);
  useEffect(()=>{ fetch('/data/products.json').then(r=>r.json()).then(setProducts).catch(()=>setProducts([])) },[]);
  const cats=useMemo(()=>["TODOS",...Array.from(new Set((products||[]).map(p=>p.category)))],[products]);
  const filtered=useMemo(()=> (products||[]).filter(p=> (cat==="TODOS"||p.category===cat) && (!q || [p.name,p.desc].join(" ").toLowerCase().includes(q.toLowerCase()))),[products,cat,q]);
  const add=(p)=>setCart(prev=>{const i=prev.findIndex(x=>x.id===p.id); if(i>=0){const n=[...prev]; n[i]={...n[i],qty:n[i].qty+1}; return n;} return [...prev,{id:p.id,name:p.name,price:Number(p.price||0),qty:1}]});
  const total=useMemo(()=>cart.reduce((s,i)=>s+i.price*i.qty,0),[cart]);
  if(!products) return <div className="min-h-screen grid place-items-center">Cargando…</div>;
  return (<div className="max-w-7xl mx-auto px-4 py-6">
    <header className="flex items-center gap-3 mb-4">
      <h1 className="text-xl font-bold">ElectroHome</h1>
      <div className="relative ml-auto w-full max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400"/>
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Buscar…" className="w-full bg-white rounded-xl pl-10 pr-4 py-2 border"/>
      </div>
      <div className="ml-2 flex items-center gap-2"><ShoppingCart className="w-5 h-5"/>{cart.reduce((s,i)=>s+i.qty,0)}</div>
    </header>
    <div className="flex flex-wrap gap-2 mb-4">{cats.map(c=><button key={c} onClick={()=>setCat(c)} className={`px-3 py-1 rounded-xl border ${cat===c?'bg-emerald-600 text-white':'bg-emerald-50 border-emerald-200 text-emerald-800'}`}>{c}</button>)}</div>
    <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {filtered.map(p=>(<article key={p.id} className="border rounded-xl overflow-hidden bg-white">
        <div className="aspect-[4/3] bg-neutral-100 grid place-items-center">{p.image?<img src={p.image} alt={p.name} className="w-full h-full object-cover"/>:null}</div>
        <div className="p-3">
          <h4 className="font-semibold line-clamp-2">{p.name}</h4>
          <p className="text-sm text-neutral-600 line-clamp-2">{p.desc||''}</p>
          <div className="mt-2 flex items-center justify-between"><div className="font-bold">{fmt(p.price||0)}</div><button onClick={()=>add(p)} className="px-3 py-1 rounded-lg bg-emerald-600 text-white text-sm flex items-center gap-1"><Plus className="w-4 h-4"/> Agregar</button></div>
        </div>
      </article>))}
    </div>
    <footer className="mt-6 text-sm text-neutral-600">© {new Date().getFullYear()} ElectroHome</footer>
  </div>);
}